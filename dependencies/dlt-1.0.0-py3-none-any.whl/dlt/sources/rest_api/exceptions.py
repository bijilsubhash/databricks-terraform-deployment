from dlt.common.exceptions import DltException


class RestApiException(DltException):
    pass


# class Paginator
