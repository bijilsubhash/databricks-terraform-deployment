from dlt.destinations.impl.lancedb.lancedb_adapter import lancedb_adapter
